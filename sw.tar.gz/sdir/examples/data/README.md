This folder contains all the surface and volumetric meshes that are necessary to run the  sample programs.

## Acknowldegments
Many thanks to [Keenan Crane](https://www.cs.cmu.edu/~kmcrane/index.html) for releasing Blub and Spot to the public domain.
